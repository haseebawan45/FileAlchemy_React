package com.example.swipe_turret

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
